import "../App.css";

function BrandingDialogueBox() {
  return (
    <>
      <div className="brandingdialoguebox">
        <label htmlFor="message">Message:</label>
        <br />
        <textarea placeholder="type of services" />
      </div>
    </>
  );
}

export default BrandingDialogueBox;
